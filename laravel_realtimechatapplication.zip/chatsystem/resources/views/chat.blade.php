<html>
<head>
<meta name="csrf-token" content="{{ csrf_token() }}">

</head>
<link href="{{ asset('css/app.css') }}" rel="stylesheet">
<style>
.list-group{
    overflow-y:scroll;
    height:250px;
}
</style>
<body>
    <div class="container" id="app">
        <br>
        <div class="row">
            <div class="col-md-4 offset-md-3">
            <li class="list-group-item active">Chat Application<span style="color:red">( @{{ numberOfUser }} )</span></li>
            <ul class="list-group" v-chat-scroll>
                <message
                v-for = 'value,index in chat.message'
                :color=chat.color[index]
                :key = value.index  
                :user=chat.user[index]
                :time=chat.time[index]
                >
                    @{{ value }} 
                </message>
            </ul>
            <input type="text"  class="form-control" placeholer="type your msg here..."
            @keyup.enter='send' v-model='message'>
            <span style="color:green">@{{ typing }}<span>

            </div>
        </div>
    </div>
</body>

<script src="{{ asset('js/app.js') }}"></script>

</html>