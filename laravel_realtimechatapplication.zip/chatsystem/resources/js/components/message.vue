<template>
<div>
    <li class="list-group-item" :class="className"><slot></slot>
    <small>{{ time }}</small>
    </li>
    <small class="float-right" :class="badgeColor">{{ user }}</small>
    </div>

</template>

<script>
    export default {
        props:[
           'color' ,
           'user' , 
           'time' , 
           'typing' , 
        ],
        computed:{
            className()
            {
                return 'list-group-item-'+this.color
            },
            badgeColor()
            {
                return 'badge-'+this.color

            }
        },
        mounted() {
            console.log('Component mounted.')
        }
    }
</script>
